package Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import Pupil.RPNcompute;
class RPNcomputeTest {
	@Test
	void testRPNcalculate1() {
	   assertEquals(21, new RPNcompute().RPNcalculate("24 - 3 / 3 -2"));
	}
	@Test
	void testRPNcalculate2() {
	   assertEquals(Double.NEGATIVE_INFINITY,
				new RPNcompute().RPNcalculate("24 - 3 / 0 - 2"));
	}
	@Test
	void testRPNcalculate3() {
	   assertEquals(11088, new RPNcompute().RPNcalculate("42 * ( 11 * 22 / 11 ) * 12"));
	}
}
